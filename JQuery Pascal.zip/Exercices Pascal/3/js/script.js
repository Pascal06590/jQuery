//------------- 01 AFFICHER CACHER -------------------
$(document).ready(function () {
	$('#depart1').click(function(){
	$('#violet').hide('slow');
	});
	$('.reload').click(function(){
	$('#violet').show('slow');
	});
});
//------------- 02 FONDU-------------------

$('#depart2').click(function(){ 
$('#jaune').hide('slow');
  $('#blanc').text('Hello world!');
});
  $('#orange').mouseover(function(){
  	$('#orange').fadeOut('slow');
  	$('#orange').fadeIn('slow');
});
$('.reload').click(function(){
	$('#jaune').show('slow'); 
});

//------------- 03 SLIDE-------------------

$('#depart3').click(function(){
$('#noir').slideUp('slow'); 
});
  $('#marron').mouseover(function(){
  	$('#marron').slideToggle('slow');
});
$('#gris').click(function(){
	$('#marron').slideToggle('slow');
	$(this).slideUp('slow');
		$(this).slideDown('slow');
});
$('.reload').click(function(){
	$('#noir').show('slow'); 
		$('#marron').show('slow'); 
	$('#gris').show('slow'); 
});

//------------- 04 ANIMATE-------------------

$('#depart4').click(function(){
	$('#rouge').animate({height: '300px', left: '-600px'},2000);
	$('#vert').animate({height: '300px', left: '600px'},2000);
});
$('.reload').click(function(){
	$('#rouge').animate({height: '100px', left: '0px'},2000); 
	$('#vert').animate({height: '100px', left: '0px'},2000); 
});

//------------- 05 DELAI DESACTIVER------------

$('#depart5').click(function(){
$('#pink').delay(2000).fadeOut('slow');
$('#cyan').hide();
});
$('#desactiver').click(function(){
	$('#pink').show('slow');
	$('#cyan').show();
});
$('.reload').click(function(){
$('#pink').show();
$('#cyan').show();
})